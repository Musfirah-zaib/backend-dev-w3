
//main module
//import functions
const {sum,sub}=require('./math');//for customize 
console.log("hi");
let result=sum(9,7);
let subtract=sub(9,7);
console.log(`sum iss ${result}`);
console.log(`sub iss ${subtract}`);

