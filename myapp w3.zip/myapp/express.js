const express_project=require('express');
const app=express_project;
app.get('/',(req,res)=>{
    res.send('welcomeexpress about server');
})
app.get('/home',(req,res)=>{
    res.send('welcomeexpress server');
})

app.get('/about',(req,res)=>{
    res.send('welcomeexpress  about server');
})
app.listen(6000,'10.9.3.31',()=>{
        console.log('express server is start');
})